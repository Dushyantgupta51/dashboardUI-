
import 'package:stacked/stacked.dart';
class ProfileViewModal extends BaseViewModel {
bool light = true;

}
